﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace SearchingFromFile
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        List<string> fileLoad; // list to keep the loaded items from the file
        List<string> searchResults; //list to keep the search results

        private void srch_Click(object sender, RoutedEventArgs e)
        {
            //Load the file
            fileLoad = loadFile();

            searchResults = searchItem(srchTxtBox.Text, fileLoad);

            //Displaying the search results
            srchOutput.Text = searchResults[0];

        }

        private List<string> searchItem(string searchText, List<string> fileItems)
        {
            List<string> tempListSearchResult = new List<string>();

            for (int i = 0; i < fileItems.Count; i++) //go through the file items to search the text entered in the text box
            {
                if (fileItems[i].Contains(searchText))
                {
                    tempListSearchResult.Add(fileItems[i]);
                }
               
            }

            //check if ther is some value in the searched result
            if (tempListSearchResult.Count==0)
            {
                tempListSearchResult.Add(searchText + " was not found");
            }


            //return the search result
            return tempListSearchResult;
        }
        private List<string> loadFile()
        {
            List<string> tempList = new List<string>(); //a temp list of file items to return to the calling method

            StreamReader someFileReader = new StreamReader("Country.txt");

           
            while (!someFileReader.EndOfStream)
            {
                string country = someFileReader.ReadLine();
                tempList.Add(country);
            }

            someFileReader.Close();
            return tempList;

        }
    }
}
